# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
#   Desc.:      Prints the mario pyramid
#   Purpose:    Following along with pset6
#   Author:     Joel Tannas
#   Date:       Jan 26, 2017
#   
#   Licensing Info:
#   None
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------

# Imports:
import cs50

# Functions:

# ---------------------------------------------------------------------------
#   Desc.:      Prints the mario pyramid
#   Purpose:    Following along with pset6
#   Author:     Joel Tannas
#   Date:       Jan 26, 2017
#
#   Bugs, Limitations, and Other Notes:
#   - doing 'more comfortable' version
# ---------------------------------------------------------------------------

# Prompt the user for a positive integer
while True:
    print("# of steps: ", end = "")
    steps = cs50.get_int()
    if steps > 0:
        break

# Iterate through each layer of the pyramid    
for i in range(steps):
    
    # Create the initial blank space
    print(" " * (steps - i - 1), end = "")
    
    # Create the left steps
    print("#" * (i + 2), end = "")
    
    # Create the center gap
    print("  ", end = "")
    
    # Create the right steps
    print("#" * (i + 2))
import nltk
import sys

class Analyzer():
    """Implements sentiment analysis."""

# ---------------------------------------------------------------------------
#   Desc.:      Returns a list of lines from a provided file
#   Purpose:    Internal method for loading a file of words into a list
#   Author:     Joel Tannas
#   Date:       Feb 01, 2017
#
#   Bugs, Limitations, and Other Notes:
#   - 
# ---------------------------------------------------------------------------    
    def _loadlist(self, fpath):
        """Internal method for loading positive/negative word lists"""
    
        # Try to open the provided file
        try:
            txt_file = open(fpath, "r")
        except:
            sys.exit("Could not open the work list file")
        
        # Read the lines into a temporary list then close the file
        lines = txt_file.readlines()
        txt_file.close()
        
        # Create the final list variable
        mylist = []
        
        # Transfer lines to the final list, validating along the way
        for line in lines:
            if not line.startswith(";") and line.strip() != "":
                mylist.append(line.strip())
        
        # Return the list to the calling function     
        return mylist

# ---------------------------------------------------------------------------
#   Desc.:      Initializes the analyser object using provided word lists
#   Purpose:    Loading the positive & negative word lists to analyze with
#   Author:     Joel Tannas
#   Date:       Feb 01, 2017
#
#   Bugs, Limitations, and Other Notes:
#   - 
# ---------------------------------------------------------------------------
    def __init__(self, positives, negatives):
        """Initialize Analyzer."""

        # Load the positives list
        self.positives = self._loadlist(positives)

        # Load the negatives list
        self.negatives = self._loadlist(negatives)
        
# ---------------------------------------------------------------------------
#   Desc.:      Returns a score of estimate sentiment for a provided text
#   Purpose:    Sentiment analysis of tweets & other natural language
#   Author:     Joel Tannas
#   Date:       Feb 01, 2017
#
#   Bugs, Limitations, and Other Notes:
#   - 
# ---------------------------------------------------------------------------
    def analyze(self, text):
        """Analyze text for sentiment, returning its score."""

        # Split the text into tokens (aka individual words)
        tokenizer = nltk.tokenize.TweetTokenizer()
        tokens = tokenizer.tokenize(text)
        
        # Analyze each token
        score = 0.0
        for token in tokens:
            score += int(token.lower() in self.positives)
            score -= int(token.lower() in self.negatives)
        
        # Finish
        return score

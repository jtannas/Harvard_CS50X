# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
#   Desc.:      Implements Caesar cypher encryption in python
#   Purpose:    Following along with pset6 of CS50X
#   Author:     Joel Tannas
#   Date:       Jan 31, 2017
#   
#   Licensing Info:
#   None
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------

# Imports:
import cs50
import sys

# Functions:

# ---------------------------------------------------------------------------
#   Desc.:      Implements Caesar cypher encryption in python
#   Purpose:    Following along with pset6 of CS50X
#   Author:     Joel Tannas
#   Date:       Jan 31, 2017
#
#   Bugs, Limitations, and Other Notes:
#   - Int check is from http://stackoverflow.com/a/5424739
#   - String concatentation from https://waymoot.org/home/python_string/
# ---------------------------------------------------------------------------
def main():
    
    # Set the number of letters in the alphabet
    LETTERS = 26
    
    # Retrieve the cipher number from the arguments
    if len(sys.argv) != 2:
        print("Usage: caesar d")
        return 1
    else:
        rot_k = sys.argv[1]
        
    # Verify that an integer was provided
    try:
        rot_k = int(rot_k)
    except ValueError:
        print("Please provide an integer as the command line argument")
        return 2
        
    # Ask for the text to cipher
    print("plaintext: ", end = "")
    intext = cs50.get_string()
    
    # Build a string by rotating the alpha characters of the input text
    outtext = ''
    for char in intext:
        if char.isalpha():
            base = ord('a') if char.islower() else ord('A')
            index = (ord(char) + rot_k - base) % LETTERS
            outtext += chr(base + index)
        else:
            outtext += char
    
    # Print the resulting coded text    
    print("ciphertext: " + outtext)
    
# Main Trigger
if __name__ == "__main__":
    main()
    

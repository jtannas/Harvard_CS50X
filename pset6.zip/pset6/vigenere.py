# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
#   Desc.:      Implements Vigenere cypher encryption in python
#   Purpose:    Following along with pset6 of CS50X
#   Author:     Joel Tannas
#   Date:       Jan 31, 2017
#   
#   Licensing Info:
#   None
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------

# Imports:
import cs50
import sys

# Functions:

# ---------------------------------------------------------------------------
#   Desc.:      Implements Vigenere cypher encryption in python
#   Purpose:    Following along with pset6 of CS50X
#   Author:     Joel Tannas
#   Date:       Jan 31, 2017
#
#   Bugs, Limitations, and Other Notes:
#   - String concatentation from https://waymoot.org/home/python_string/
# ---------------------------------------------------------------------------
def main():
    
    # Set the number of letters in the alphabet
    LETTERS = 26
    
    # Retrieve the cipher from the arguments
    if len(sys.argv) != 2:
        print("Usage: vigenere cipher_word")
        return 1
    else:
        cipher = (sys.argv[1]).lower()
        
    # Verify that the cipher is composed of alpha characters
    if cipher.isalpha() == False:
        print("The cipher must be letters only - no punctuation or digits")
        return 2
        
    # Ask for the text to cipher
    print("plaintext: ", end = "")
    intext = cs50.get_string()
    
    # Build a string by rotating the alpha characters of the input text
    outtext = ''
    k = 0
    
    for i in range(len(intext)):
        
        # Determine the next character to examine in the plain text
        char = intext[i]

        # Rotate if it is a character
        if char.isalpha():
            
            # Determine the rotation key, increment the key index for later
            rot_k = ord(cipher[k]) - ord('a')
            k = (k + 1) % len(cipher)
            
            # Perform the rotation relative to 'a'
            base = ord('a') if char.islower() else ord('A')
            index = (ord(char) + rot_k - base) % LETTERS
            outtext += chr(base + index)

        else:
            outtext += char
    
    # Print the resulting coded text    
    print("ciphertext: " + outtext)
    
# Main Trigger
if __name__ == "__main__":
    main()
    

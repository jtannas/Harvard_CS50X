# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
#   Desc.:      Makes change for a given amount of money & coin
#   Purpose:    Pset6
#   Author:     Joel Tannas
#   Date:       Jan 26, 2017
#   
#   Licensing Info:
#   None
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------

# Imports:
import cs50

# Functions:

# ---------------------------------------------------------------------------
#   Desc.:      Makes change for a given amount of money & coin
#   Purpose:    Pset6
#   Author:     Joel Tannas
#   Date:       Jan 26, 2017
#
#   Bugs, Limitations, and Other Notes:
#   - 
# ---------------------------------------------------------------------------

# Prompt the user for the amount of change in dollars
while True:
    print("Change to make: ", end = "")
    change = cs50.get_float()
    if change > 0:
        break
    
# Convert the change into cents, initialize the coin counter
change = round(change * 100, 0)
coins = 0

# Define and massage an array of currency coins to use for making change
valid_coins = sorted([25, 10, 5, 1], reverse = True)

# Iterate through the valid coins to make change
for coin in valid_coins:
    
    # Find how many coins can be extracted
    coins += change // coin
    
    # Extract them using modulo
    change %= coin
    
print("coins : {}, remainder : {}".format(int(coins), change/100))
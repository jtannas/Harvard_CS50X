# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
#   Desc.:      Cracks a hashed password by brute force
#   Purpose:    Pset6, Crack implemented in Python      
#   Author:     Joel Tannas
#   Date:       Feb 15, 2017
#   
#   Licensing Info:
#   None
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------

# Imports:
import cs50
import sys
import crypt
import string
import itertools

# Functions:

# ---------------------------------------------------------------------------
#   Desc.:      ./crack hashed
#   Purpose:    Cracks a hashed password of 4 alpha chars or less
#   Author:     Joel Tannas
#   Date:       Feb 15, 2017
#
#   Bugs, Limitations, and Other Notes:
#   - help from http://stackoverflow.com/a/16060908
#   - more help from http://stackoverflow.com/a/7074066
#   - Assumes that each password has been hashed with 
#        C’s DES-based (not MD5-based) crypt function.
# ---------------------------------------------------------------------------
def main():
    
    # Validate the input arguments
    if len(sys.argv) != 2:
        print("Usage: ./crack hash")
        return 1
    
    # Make a list string of valid characters
    charlist = string.ascii_letters
    
    # Iterate over the possible combinations
    MAXLEN = 4
    for i in range(MAXLEN):
        print("Working on {} length passwords...".format(i + 1))
        possibles = list(itertools.product(charlist, repeat = i + 1))
        
        # Compare the crypt of each word to the hash
        for possible in possibles:
            hashed = crypt.crypt("".join(possible), "50")
            if  hashed == sys.argv[1]:
                print("".join(possible))
                return
                break
            
    print("Not found")
    return 1

# Main Trigger
if __name__ == "__main__":
    main()
    

# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
#   Desc.:      Checking to see if a provided credit card # is valid
#   Purpose:    Pset6 - learning python
#   Author:     Joel Tannas
#   Date:       Jan 26, 2017
#   
#   Licensing Info:
#   None
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------

# Imports:
import cs50
import math

# Functions:

# ---------------------------------------------------------------------------
#   Desc.:      Checking to see if a provided credit card # is valid
#   Purpose:    Pset6 - learning python
#   Author:     Joel Tannas
#   Date:       Jan 26, 2017
#
#   Bugs, Limitations, and Other Notes:
#   - Uses Luhn's Algorithm
#   - Splitting help is from http://stackoverflow.com/q/974952
#   - Dictionary idea from http://stackoverflow.com/a/103081
#   - using len(digits) doesn't give the expected result
# ---------------------------------------------------------------------------

# Define a dictionary using valid card tuples(length, starting) as keys
# JTannas Note: I like this method because it is logically straightforward
card_check = {(13, 40): "VISA",
                (13, 41): "VISA",
                (13, 42): "VISA",
                (13, 43): "VISA",
                (13, 44): "VISA",
                (13, 45): "VISA",
                (13, 46): "VISA",
                (13, 47): "VISA",
                (13, 48): "VISA",
                (13, 49): "VISA",
                (15, 34): "AMEX",
                (15, 37): "AMEX",
                (16, 40): "VISA",
                (16, 41): "VISA",
                (16, 42): "VISA",
                (16, 43): "VISA",
                (16, 44): "VISA",
                (16, 45): "VISA",
                (16, 46): "VISA",
                (16, 47): "VISA",
                (16, 48): "VISA",
                (16, 49): "VISA",
                (16, 51): "MASTERCARD",
                (16, 52): "MASTERCARD",
                (16, 53): "MASTERCARD",
                (16, 54): "MASTERCARD",
                (16, 55): "MASTERCARD",
            }
            
# Prompt the user for a card number to test
while True:
    card = cs50.get_float()
    if card > 0:
        break

# Map the digits to a string & get the length
digits = str(card)
length = int(math.log(card, 10)) + 1

# Initialize a checksum
checksum = 0

# Iterate through the digits from right to left
for i in range(length):
    
    digit = int(digits[length - i - 1])
    
    # Apply Luhn's algorithm, modifying each 2nd digit 
    if (i % 2) == 1:
        digit *= 2
        checksum += digit % 10
        checksum += digit // 10
    else:
         checksum += digit

# validate checksum
if checksum % 10 != 0:
    print("INVALID")
    exit()

# validate company's identifier
result = card_check.get((length, int(digits[:2])),"INVALID")
print("{}".format(result))
/**
 * fifteen.c
 *
 * Computer Science 50
 * Problem Set 3
 *
 * Implements Game of Fifteen (generalized to d x d).
 *
 * Usage: fifteen d
 *
 * whereby the board's dimensions are to be d x d,
 * where d must be in [DIM_MIN,DIM_MAX]
 * 
 * -----------------------------------------------------------------
 * JTannas Edit: I treat board[][] as a linear array for simplicity.
 * i.e. board[x][y] -> board[0][y * d + x]
 * The advantage of this is that tile locations can be passed from 
 * functions via the return value - making it easier to break up the
 * code into simple chunks.
 * 
 * This involved a minor edit to main ([i][j] -> [0][j * d + i])
 * -----------------------------------------------------------------
 *
 * Note that usleep is obsolete, but it offers more granularity than
 * sleep and is simpler to use than nanosleep; `man usleep` for more.
 */

#define _XOPEN_SOURCE 500

#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// constants
#define DIM_MIN 3
#define DIM_MAX 9

// board
int board[DIM_MAX][DIM_MAX];

// dimensions
int d;

// prototypes
void clear(void);
void greet(void);
void init(void);
void draw(void);
bool move(int tile);
bool won(void);
bool swap(int tile1, int tile2);
int search(int target);

// Implementation
int main(int argc, string argv[])
{
    // ensure proper usage
    if (argc != 2)
    {
        printf("Usage: fifteen d\n");
        return 1;
    }

    // ensure valid dimensions
    d = atoi(argv[1]);
    if (d < DIM_MIN || d > DIM_MAX)
    {
        printf("Board must be between %i x %i and %i x %i, inclusive.\n",
            DIM_MIN, DIM_MIN, DIM_MAX, DIM_MAX);
        return 2;
    }

    // open log
    FILE* file = fopen("log.txt", "w");
    if (file == NULL)
    {
        return 3;
    }

    // greet user with instructions
    greet();

    // initialize the board
    init();

    // accept moves until game is won
    while (true)
    {
        // clear the screen
        clear();

        // draw the current state of the board
        draw();

        // log the current state of the board (for testing)
        for (int i = 0; i < d; i++)
        {
            for (int j = 0; j < d; j++)
            {
                // Modified from: fprintf(file, "%i", board[i][j]);
                fprintf(file, "%i", board[0][i * d + j]);
                if (j < d - 1)
                {
                    fprintf(file, "|");
                }
            }
            fprintf(file, "\n");
        }
        fflush(file);

        // check for win
        if (won())
        {
            printf("ftw!\n");
            break;
        }

        // prompt for move
        printf("Tile to move: ");
        int tile = GetInt();
        
        // quit if user inputs 0 (for testing)
        if (tile == 0)
        {
            break;
        }

        // log move (for testing)
        fprintf(file, "%i\n", tile);
        fflush(file);

        // move if possible, else report illegality
        if (!move(tile))
        {
            printf("\nIllegal move.\n");
            usleep(500000);
        }

        // sleep thread for animation's sake
        usleep(500000);
    }
    
    // close log
    fclose(file);

    // success
    return 0;
}

/**
 * Clears screen using ANSI escape sequences.
 */
void clear(void)
{
    printf("\033[2J");
    printf("\033[%d;%dH", 0, 0);
}

/**
 * Greets player.
 */
void greet(void)
{
    clear();
    printf("WELCOME TO GAME OF FIFTEEN\n");
    usleep(2000000);
}

/* -------------------------------------------------------------------------
*   Desc.:      Initialize the game board with tiles numbered 1 to d * d - 1
*   Purpose:    To give a starting point for the game    
*   Author:     Joel Tannas
*   Date:       Dec 06, 2016
*
*   Bugs, Limitations, and Other Notes:
*   - fills board array with values but does not actually print them
*   - Required a square board of at least 2 x 2
*   - C allocates memory for a 2D array continguously and row-wise
*       This allows us to access data using a linear index 
* ------------------------------------------------------------------------*/
void init(void)
{
    // Iterate through the board
    for (int i = 0; i < d * d; i++)
    {
        // Set the initial value, starting at d * d - 1, then decreasing
        board[0][i] = d * d - 1 - i;
    }
    
    // On boards with an even number of tiles, swap the 1 and 2
    if ((d * d) % 2 == 0)
    {
        swap(d * d - 2, d * d - 3);
    }
}

/* -------------------------------------------------------------------------
*   Desc.:      Prints the board in its current state
*   Purpose:    To let the user see the board state
*   Author:     Joel Tannas
*   Date:       Dec 06, 2016
*
*   Bugs, Limitations, and Other Notes:
*   - C allocates memory for a 2D array continguously and row-wise
*       This allows us to access data using a linear index 
*   - Example Pattern:
*
*       +---+---+---+
*       |  1|  2|  3|
*       +---+---+---+
*       |  4|  5|  6|
*       +---+---+---+
*       |  7|  8|   |
*       +---+---+---+
* 
*   - One more loop iteration than normal is run to make the final line
* ------------------------------------------------------------------------*/
void draw(void)
{
    // Print alternating decor & data lines, run 1 extra time for decor
    printf("\n");
    for (int y = 0; y <= d; y++)
    {
        // Print a Decoration row
        printf("+");
        for (int x = 0; x < d; x++)
        {
            printf("---+");
        }
        printf("\n");
        
        // Break loop if final decoration line is complete, else continue
        if (y == d)
        {
            break;
        }
        else
        {
            // Print a line of Data
            printf("|");
            for (int x = 0; x < d; x++)
            {
                // Show the zero tile as blank, else show the value
                if (board[0][y * d + x] == 0)
                {
                    printf("   |");
                }
                else
                {
                    printf("%3d|", board[0][y * d + x]);
                }
            }
            printf("\n");
        }
    }
    
    // Print a final spacer line for aesthetics
    printf("\n");
}

/* -------------------------------------------------------------------------
*   Desc.:      If tile borders empty space, attempts to swap the blank
*                   and the tile.
*               Returns true on swap.
*               Returns false on non-adjacent or failed swap.
*   Purpose:    To move the tile per the user directives (within the rules)
*   Author:     Joel Tannas
*   Date:       Dec 06, 2016
*
*   Bugs, Limitations, and Other Notes:
*   - C allocates memory for a 2D array continguously and row-wise
*       This allows us to access data using a linear index 
* ------------------------------------------------------------------------*/
bool move(int tile)
{
    // Validate that the input is in bounds
    if (tile < 1 || tile >= d * d)
    {
        return false;
    }
    
    // Search for the void and the tile, Exit if either was not found
    int tile_index = search(tile);
    int void_index = search(0);
    if (tile_index == -1 || void_index == -1)
    {
        return false;
    }
    
    // Compare the tile and void indexes to find their relative position
    int diff = tile_index - void_index;
    if (diff == -1 * d || diff == d)
    {
        // This case occurs when the tile & void are on top of each other
        return swap(tile_index, void_index);
    }
    else if ((diff == 1 || diff == -1) && (void_index / d == tile_index / d))
    {
        // diff = +/- 1 when the tiles are linearly adjacent
        // (void_index / d == tile_index / d) when on the same row
        return swap(tile_index, void_index);
    }

    // The tile and void are not adjacent if this point has been reached
    return false;
}

/* -------------------------------------------------------------------------
*   Desc.:      Returns true if game board is in winning configuration,
*                   Else, returns false
*   Purpose:    To determine if the game has been won
*   Author:     Joel Tannas
*   Date:       Dec 06, 2016
*
*   Bugs, Limitations, and Other Notes:
*   - C allocates memory for a 2D array continguously and row-wise
*       This allows us to access data using a linear index 
* ------------------------------------------------------------------------*/
bool won(void)
{
    // Iterate through the board, checking for each tile
    for (int i = 0; i < d * d - 1; i++)
    {
        if (board[0][i] != i + 1)
        {
            return false;    
        }
    }
    
    // Do a final check for the void tile
    if (board[0][d * d - 1] != 0)
    {
        return false;
    }
    
    // No out of place values were found for this point to be reached
    return true;
}

/* -------------------------------------------------------------------------
*   Desc.:      Returns the linearized index of a given tile's position
                    On failure to find, returns -1
*   Purpose:    Internal function for finding tiles
*   Author:     Joel Tannas
*   Date:       Dec 06, 2016
*
*   Bugs, Limitations, and Other Notes:
*   - C allocates memory for a 2D array continguously and row-wise
*       This allows us to access data using a linear index 
* ------------------------------------------------------------------------*/
int search(int target)
{
    // Validate that the input is in bounds
    if (target < 0 || target >= d * d)
    {
        return -1;
    }
    
    // Iterate through the board, checking each tile for the target
    for (int i = 0; i < d * d; i++)
    {
        if (board[0][i] == target)
        {
            return i;    
        }
    }
    
    // The value was not found if this point was reached
    return -2;
}

/* -------------------------------------------------------------------------
*   Desc.:      Swaps the position of two tiles given by their linear index
*                   Returns an true on success, false on failure
*   Purpose:    Internal function for moving tiles
*   Author:     Joel Tannas
*   Date:       Dec 06, 2016
*
*   Bugs, Limitations, and Other Notes:
*   - C allocates memory for a 2D array continguously and row-wise
*       This allows us to access data using a linear index 
* ------------------------------------------------------------------------*/
bool swap(int tile1, int tile2)
{
    // Validate that input1 is in bounds
    if (tile1 < 0 || tile1 >= d * d)
    {
        return false;
    }
    
    // Validate that input2 is in bounds
    if (tile2 < 0 || tile2 >= d * d)
    {
        return false;
    }
    
    // Swap the tiles via an intermediary
    int temp1 = board[0][tile1];
    board[0][tile1] = board[0][tile2];
    board[0][tile2] = temp1;
    
    // No errors, return true
    return true;
}
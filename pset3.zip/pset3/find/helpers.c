/**
 * helpers.c
 *
 * Computer Science 50
 * Problem Set 3
 *
 * Helper functions for Problem Set 3.
 */
 
// Includes
#include <cs50.h>
#include <stdio.h> 
#include "helpers.h"

// Prototypes

// Implementation
bool search(int value, int values[], int n)
{
    /* -------------------------------------------------------------------------
    *   Description:    Return true if value is in array of n values, else false
    *   Purpose:        For finding if a number exists within a provided array
    *   Author:         Joel Tannas
    *   Date:           Dec 02, 2016
    *
    *   Bugs, Limitations, and Other Notes:
    *   - Contains commented out code for a linear search
    *   - Uses the bisection method and requiring an ascending sorted array
    * ------------------------------------------------------------------------*/
 
    // Validate Array Size
    if (n < 1)
    {
        printf("The array size must be at least 1");
        return false;
    }
    
    /* Linear Search Method
    *for (int i = 0; i < n; i++)
    *{
    *    if (values[i] == value)
    *    {
    *        return true;
    *    }
    *}
    */
    
    // Bisection Search Method
    int lbound = 0;
    int ubound = n - 1;
    
    while (ubound >= lbound)
    {
        // Find the middle of the array (the bisector)
        int bisector = (lbound + ubound) / 2;
        
        // Check the bisector for the value. Adjust bounds if not.
        if (values[bisector] == value)
        {
            return true;
        }
        else if (values[bisector] < value)
        {
            lbound = bisector + 1;
        }
        else if (values[bisector] > value)
        {
            ubound = bisector - 1;
        }
    }
    
    
    // Failed to find value, return false
    return false;
}

void sort(int values[], int n)
{
    /* -------------------------------------------------------------------------
    *   Description:    Sorts array of n values using bubblesort.
    *   Purpose:        For finding if a number exists within a provided array
    *   Author:         Joel Tannas
    *   Date:           Dec 05, 2016
    *
    *   Bugs, Limitations, and Other Notes:
    *   - Uses BubbleSort, since restricted to O(n^2) by the pset
    *   - Bubblesort: Where pairs of adjacent values are sorted from values[0]
    *       to values[n-1]. This leads to the largest value 'bubbling' to the
    *       end. This is repeated up to n times to sort the whole array.
    *       Since the largest value bubbles to the top, subsequent iterations
    *       do not have to check it. If no out-of-order pairs are found, break.
    * ------------------------------------------------------------------------*/
    
    // Repeatedly iterate through the array, bubbling larger values upward
    for (int i = 0; i < n; i++)
    {
        // Use a boolean 'flag' to capture whether a swap has been made
        bool done = true;
        
        // Bubble from 0 to the last unsorted value (values[n - 1 - i])
        for (int j = 0; j < (n - 1 - i); j++)
        {
            // Compare an adjacent pair of values, swap if out of order
            if (values[j] > values[j + 1])
            {
                // Set the flag to signal incomplete
                done = false;
                
                // Swap the values via a placeholder variable
                int temp = values[j + 1];
                values[j + 1] = values[j];
                values[j] = temp;
            }
        }
        
        // If no out of order pairs were found, exit the loop
        if (done == true)
        {
            printf("Bubbling Complete; ");
            break;
        }
    }
    
    // Paranoia Loop: Verify that the array is sorted
    for (int i = 0; i < (n - 1); i++)
    {
        // If an out of order pair is found, tell the user
        if (values[i] > values[i + 1])
        {
            printf("SORT FAILED\n");
            return;
        }
    }

    // Sort Verified; Return
    printf("Sort Verified\n");
    return;
}